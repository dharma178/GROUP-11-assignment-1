from django.shortcuts import render

# Crete your views here.
def hello(request):
    return reader(request, 'task1_app/hello.html')

    def order (request):
        Company_name=" Tarzen Mobile Shop"
        name= "customer"
        ship_date= datetime.date(2022,03,22)
    item_list=["iphone","androids","apple","watch"]
    warranty=True


    context_data ={
    "company" Company_name,
    "person_name":name,
    "ship_date"=ship_date
    "item_list"=item_list
    "ordered_warrenty"= warranty
    }
returnr render(request,"task1_app/mobilephone.html")

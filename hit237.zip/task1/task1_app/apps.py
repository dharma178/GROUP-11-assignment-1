from django.apps import AppConfig


class Task1AppConfig(AppConfig):
    name = 'task1_app'
